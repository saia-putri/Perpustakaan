@extends('pengunjung.mainapps')
@section('title')
    Home Pengunjung
@endsection
@section('content')
    <section id="hero"
        class="hero w-100 h-100 p-3 mx-auto text-center d-flex justify-content-center align-items-center text-white">
        <main>
            <div class="container selamat">
                <h1>SELAMAT DATANG</h1>
                <h5>Layanan Informasi Perpustakaan Pengadilan Militer I-04 Palembang</h5>
            </div>
        </main>
    </section>
@endsection
